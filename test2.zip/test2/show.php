<?php
include_once 'test2.php';
session_start();
if($_SERVER['REQUEST_METHOD']=='POST'){
    if(!empty($_POST['first_name'])){
        if(preg_match("/([a-zA-Z])/", $_POST['first_name'])){
            $_POST['first_name']= filter_var($_POST['first_name'], FILTER_SANITIZE_STRING);
            $obj= new test2();
            $obj->setData($_POST)->store();
        }
        else{
            $_SESSION['message']="Input Invalid";
            header("location:popup.php");
        }
    }
    else{
        $_SESSION['message']="Input can't be empty";
        header("location:popup.php");
    }

}
else{
    header("location:popup.php");
}
$data=$obj->setData($_GET)->show();
$date=$obj->setData($_GET)->showDate();
$name=$obj->setData($_GET)->showName();
$income=$obj->setData($_GET)->showIncome();
$expense=$obj->setData($_GET)->showExpense();

foreach($data as $item)
echo "The id is:".$item['id'].'<br>';
foreach($date as $item)
echo "The date is:".$item['date'].'<br>';
foreach($name as $item)
    echo "The name is:".$item['first_name'].$item['last_name'].'<br>';
foreach($income as $item)
    echo "The income is:".$item['totalincome'].'<br>';
foreach($expense as $item)
    echo "The expense is:".$item['totalexpense'].'<br>';

if($expense<$income){
    if($expense<$income*(50/100)){
        echo "The rank is RICH";
    }
    elseif($income*(50/100)*$expense<$income*(75/100)){
        echo "The rank is MIDDLE";
    }
    elseif($expense<$income*(75/100)){
        echo "The rank is POOR";
    }
    else{
        echo "there is no rank";
    }
}
else{
    $difference=($expense-$income);
    $percentage=($difference/$income)*100;
    echo "Salary is low and the percentage is:" . $percentage;
}
