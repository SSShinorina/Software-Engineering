<?php
/**
 * Created by PhpStorm.
 * User: LENOVO
 * Date: 3/25/2019
 * Time: 5:54 PM
 */

class test2
{
    public $id;
    public $date;
    public $email;
    public $salary;
    public $tips;
    public $bonus;
    public $other_allowances;
    public $transport;
    public $bills;
    public $house_rent;
    public $meals;
    public $first_name;
    public $last_name;


    public function setData($data = '')
    {
        if(array_key_exists('id', $data))
        {
            $this->id = $data['id'];
        }
        if(array_key_exists('date', $data))
        {
            $this->date = $data['date'];
        }
        if(array_key_exists('email', $data))
        {
            $this->email = $data['email'];
        }
        if(array_key_exists('salary', $data))
        {
            $this->salary = $data['salary'];
        }
        if(array_key_exists('tips', $data))
        {
            $this->tips = $data['tips'];
        }
        if(array_key_exists('bonus', $data))
        {
            $this->bonus = $data['bonus'];
        }
        if(array_key_exists('other_allowances', $data))
        {
            $this->other_allowances = $data['other_allowances'];
        }
        if(array_key_exists('transport', $data))
        {
            $this->transport = $data['transport'];
        }
        if(array_key_exists('bills', $data))
        {
            $this->bills = $data['bills'];
        }
        if(array_key_exists('house_rent', $data))
        {
            $this->house_rent = $data['house_rent'];
        }
        if(array_key_exists('meals', $data))
        {
            $this->meals = $data['meals'];
        }
        if(array_key_exists('first_name', $data))
        {
            $this->first_name = $data['first_name'];
        }
        if(array_key_exists('last_name', $data))
        {
            $this->last_name = $data['last_name'];
        }

        return $this;
    }

    public function store()
    {
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=eis', 'root', '');
            $sql="INSERT INTO `income_expense` (`id`, `date`, `first_name`, `last_name`, `salary`, `tips`, `bonus`, `allowance`, `transport`, `bills`, `rent`, `meals`) 
VALUES (:id, :date, :first, :last, :salary, :tips, :bonus, :allowance, :transport, :bills, :rent, :meals)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array(
                ':id' => null,
                ':date'=>$this->date,
                ':first'=>$this->first_name,
                ':last'=>$this->last_name,
                ':salary'=>$this->salary,
                ':tips'=>$this->tips,
                ':bonus'=>$this->bonus,
                ':allowance'=>$this->other_allowances,
                ':transport'=>$this->transport,
                ':bills'=>$this->bills,
                ':rent'=>$this->house_rent,
                ':meals'=>$this->meals
            ));

            if($stmt){
                session_start();
                $_SESSION['message']="Successfully Added";

            }
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }

    }

    public function show(){
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=eis', 'root', '');
            $sql="SELECT * FROM `income_expense`";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $data=$stmt->fetchAll(PDO::FETCH_ASSOC);

            return $data;
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }

    public function showDate(){
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=eis', 'root', '');
            $sql="SELECT * FROM `income_expense`";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $date=$stmt->fetchAll(PDO::FETCH_ASSOC);

            return $date;
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }

    public function showName(){
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=eis', 'root', '');
            $sql="SELECT * FROM `income_expense`";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $name=$stmt->fetchAll(PDO::FETCH_ASSOC);

            return $name;
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }

    public function showIncome(){
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=eis', 'root', '');
            $sql="SELECT (salary+tips+bonus+allowance) as totalincome FROM `income_expense`";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $income=$stmt->fetchAll(PDO::FETCH_ASSOC);

            return $income;
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }

    public function showExpense(){
        try {
            $pdo = new PDO('mysql:host=localhost;dbname=eis', 'root', '');
            $sql="SELECT (transport+bills+rent+meals) as totalexpense FROM `income_expense`";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $expense=$stmt->fetchAll(PDO::FETCH_ASSOC);

            return $expense;
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }



}