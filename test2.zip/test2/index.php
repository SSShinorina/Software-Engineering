<html>
<head>
    <title></title>
</head>
<body>
<a href="#" onclick="MyWindow=window.open('popup.php','MyWindow',width=600,height=300);return false;">Daily Income Statement</a>
</body>
</html>