
<html>
<head>
    <title>

    </title>
</head>
<body>
<fieldset>
    <legend></legend>
    <form action="show.php" method="post">
        <label>Date:</label><br>
        <input type="date" onload="getDate()" class="form-control" id="date" name="date"><br>
        <label>Email:  </label><br>
        <input type="email" name="email" placeholder="E-mail"><br>
        <label>First Name:  </label><br>
        <input type="text" name="first_name" placeholder="First Name"><br>
        <label>Last Name:  </label><br>
        <input type="text" name="last_name" placeholder="Last Name"><br>
        <label>Income: </label><br>
        <input type="text" name="salary" placeholder="Salary"><br>
        <input type="text" name="tips" placeholder="Tips"><br>
        <input type="text" name="bonus" placeholder="Bonus"><br>
        <input type="text" name="other_allowances" placeholder="Other Allowances"><br>
        <label>Expenditure:</label><br>
        <input type="text" name="transport" placeholder="Transport"><br>
        <input type="text" name="bills" placeholder="Bills"><br>
        <input type="text" name="house_rent" placeholder="House/ Living Room Rate(Daily)"><br>
        <input type="text" name="meals" placeholder="Meals"><br>

        <input type="submit" value="Generate Statement">
    </form>
</fieldset>
</body>
</html>